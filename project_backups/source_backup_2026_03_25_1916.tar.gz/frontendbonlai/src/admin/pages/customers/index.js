export { default as CustomerList } from "./CustomerList";
export { default as CustomerForm } from "./CustomerForm";
export { default as CustomerDetail } from "./CustomerDetail";
export * from "./customerAPI";
